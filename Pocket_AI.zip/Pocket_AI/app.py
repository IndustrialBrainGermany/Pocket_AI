import json
from pathlib import Path
import shutil
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk
from openai import OpenAI
import requests

# Drag & Drop über tkinterdnd2
HAS_DND = False
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    HAS_DND = True
except ImportError:
    pass

from agent import PocketAgent
from brain import read_brain_state
import tools
from tools import BASE_DIR, CONFIG_FILE, WORKSPACE_DIR
from mcp_client import mcp_manager

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

FALLBACK_FREE_MODELS = [
    "google/gemini-2.5-flash:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "qwen/qwen-2.5-coder-32b-instruct:free",
    "openrouter/free",
]


class InspectorWindow(ctk.CTkToplevel):
    """Echtzeit-Fenster zur Anzeige der Gedanken, Tools und Ergebnisse der KI."""
    def __init__(self, master):
        super().__init__(master)
        self.title("🔍 POCKET_AI — Live-Inspektor")
        self.geometry("750x550")
        self.minsize(500, 400)
        
        self.attributes("-topmost", True)
        
        lbl_header = ctk.CTkLabel(
            self, 
            text="Echtzeit-Denkprotokoll & Tool-Ausführung", 
            font=ctk.CTkFont(size=14, weight="bold")
        )
        lbl_header.pack(padx=15, pady=(15, 5), anchor="w")
        
        self.txt_log = ctk.CTkTextbox(
            self, 
            font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word"
        )
        self.txt_log.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        self.txt_log.insert("1.0", "=== Live-Inspektor bereit. Warte auf Task-Ausführung... ===\n\n")

    def log_step(self, step_num, thought, action, observation):
        def _update():
            msg = f"━━━━━━━━━━━━━━━━ SCHRITT {step_num} / 30 ━━━━━━━━━━━━━━━━\n"
            msg += f"💭 GEDANKE:\n{thought.strip()}\n\n"
            msg += f"🛠️ AKTION / TOOL:\n{action.strip()}\n\n"
            msg += f"📥 ERGEBNIS / OBSERVATION:\n{observation.strip()}\n"
            msg += "━" * 58 + "\n\n"
            
            self.txt_log.insert("end", msg)
            self.txt_log.see("end")
            
        self.after(0, _update)


class PocketAIApp(ctk.CTk, TkinterDnD.DnDWrapper if HAS_DND else object):

    def __init__(self):
        super().__init__()
        if HAS_DND:
            self.TkdndVersion = TkinterDnD._require(self)

        self.title("POCKET_AI v1.0 — Desktop Agent")
        self.geometry("1100x820")
        self.minsize(900, 650)

        # On-Closing Event registrieren (Zombie-Killer Mechanism)
        self.protocol("WM_DELETE_WINDOW", self._on_closing)

        self.chat_history = []
        self.agent = None
        self.is_running = False
        self.attached_file_path = None
        self.mcp_switches = {}  # Speichert dynamische MCP Switches
        self.inspector_win = None

        self.config_data = self._load_config()
        self._build_ui()
        self._restore_config_to_ui()
        self._load_dynamic_mcp_ui()  # Dynamische MCP-Schalter laden

        if HAS_DND:
            self._setup_drag_and_drop()

        threading.Thread(target=self._update_model_list, daemon=True).start()

    def _on_closing(self):
        """Wird aufgerufen, wenn die Anwendung geschlossen wird."""
        mcp_manager.stop_all_servers()
        self.destroy()

    def _setup_drag_and_drop(self):
        try:
            self.drop_target_register(DND_FILES)
            self.dnd_bind('<<Drop>>', self._handle_drop)
            self.txt_chat.drop_target_register(DND_FILES)
            self.txt_chat.dnd_bind('<<Drop>>', self._handle_drop)
        except Exception:
            pass

    def _handle_drop(self, event):
        raw_data = event.data.strip()
        if raw_data.startswith('{') and raw_data.endswith('}'):
            raw_data = raw_data[1:-1]
        
        paths = raw_data.split('} {')
        if paths:
            file_path = Path(paths[0].strip('{}'))
            if file_path.exists():
                self._attach_file(file_path)

    def _update_model_list(self):
        try:
            url = "https://openrouter.ai/api/v1/models"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                data = resp.json().get("data", [])
                free_models = []
                for m in data:
                    m_id = m.get("id", "")
                    pricing = m.get("pricing", {})
                    prompt_price = float(pricing.get("prompt", 0))
                    if m_id.endswith(":free") or prompt_price == 0:
                        free_models.append(m_id)

                if free_models:
                    free_models.sort()
                    if "openrouter/free" in free_models:
                        free_models.remove("openrouter/free")
                        free_models.insert(0, "openrouter/free")

                    self.after(0, lambda: self.combo_model.configure(values=free_models))
        except Exception:
            pass

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=3)
        self.grid_rowconfigure(0, weight=1)

        # SIDEBAR
        self.sidebar = ctk.CTkFrame(self, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        self.lbl_title = ctk.CTkLabel(self.sidebar, text="POCKET_AI v1.0", font=ctk.CTkFont(size=20, weight="bold"))
        self.lbl_title.pack(anchor="w", padx=15, pady=(15, 2))

        # 1. KI Verbindung
        self.lbl_conn = ctk.CTkLabel(self.sidebar, text="1. KI-Verbindung:", font=ctk.CTkFont(weight="bold"))
        self.lbl_conn.pack(anchor="w", padx=15, pady=(10, 2))

        self.entry_url = ctk.CTkEntry(self.sidebar, placeholder_text="https://openrouter.ai/api/v1")
        self.entry_url.pack(fill="x", padx=15, pady=2)

        self.entry_key = ctk.CTkEntry(self.sidebar, placeholder_text="API Key", show="*")
        self.entry_key.pack(fill="x", padx=15, pady=2)

        self.combo_model = ctk.CTkComboBox(self.sidebar, values=FALLBACK_FREE_MODELS)
        self.combo_model.pack(fill="x", padx=15, pady=2)

        self.frame_conn_btn = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        self.frame_conn_btn.pack(fill="x", padx=15, pady=5)

        self.btn_test_conn = ctk.CTkButton(self.frame_conn_btn, text="🔗 Verbindung Testen", command=self._test_connection, width=140)
        self.btn_test_conn.pack(side="left")

        self.lbl_conn_status = ctk.CTkLabel(self.frame_conn_btn, text="⚪ Nicht geprüft", font=ctk.CTkFont(size=11))
        self.lbl_conn_status.pack(side="left", padx=10)

        # 2. Projekt-Workspace / Arbeitsordner
        self.lbl_workspace = ctk.CTkLabel(self.sidebar, text="2. Projekt-Workspace:", font=ctk.CTkFont(weight="bold"))
        self.lbl_workspace.pack(anchor="w", padx=15, pady=(10, 2))

        self.frame_workspace = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        self.frame_workspace.pack(fill="x", padx=15, pady=2)

        self.entry_workspace = ctk.CTkEntry(self.frame_workspace, placeholder_text=str(WORKSPACE_DIR))
        self.entry_workspace.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.btn_browse_workspace = ctk.CTkButton(self.frame_workspace, text="📁", width=35, command=self._select_workspace)
        self.btn_browse_workspace.pack(side="right")

        # 3. Autonomie
        self.lbl_auto = ctk.CTkLabel(self.sidebar, text="3. Autonomie-Level:", font=ctk.CTkFont(weight="bold"))
        self.lbl_auto.pack(anchor="w", padx=15, pady=(10, 2))

        self.combo_autonomy = ctk.CTkOptionMenu(
            self.sidebar,
            values=["WORKSPACE_SANDBOX (Ausgewogen)", "STRICT (Manuelle Freigabe)", "UNATTENDED (Vollautonom)"],
        )
        self.combo_autonomy.pack(fill="x", padx=15, pady=2)

        # 4. Werkzeuge Header + "+ MCP" Button
        self.frame_tools_header = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        self.frame_tools_header.pack(fill="x", padx=15, pady=(10, 2))

        self.lbl_tools = ctk.CTkLabel(self.frame_tools_header, text="4. Werkzeuge & MCP:", font=ctk.CTkFont(weight="bold"))
        self.lbl_tools.pack(side="left")

        self.btn_add_mcp = ctk.CTkButton(
            self.frame_tools_header, 
            text="+ MCP", 
            width=55, 
            height=22, 
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#10B981", 
            hover_color="#059669",
            command=self._import_mcp_dialog
        )
        self.btn_add_mcp.pack(side="right")

        self.frame_tools = ctk.CTkScrollableFrame(self.sidebar, height=130)
        self.frame_tools.pack(fill="both", expand=True, padx=15, pady=5)

        self.sw_web = ctk.CTkSwitch(self.frame_tools, text="🌐 Web & Downloads (5 Tools)")
        self.sw_web.pack(anchor="w", pady=4)

        self.sw_vision = ctk.CTkSwitch(self.frame_tools, text="📸 Screenshots & Vision")
        self.sw_vision.pack(anchor="w", pady=4)

        self.sw_terminal = ctk.CTkSwitch(self.frame_tools, text="🖥️ Terminal & Python (3 Tools)")
        self.sw_terminal.pack(anchor="w", pady=4)

        self.sw_files = ctk.CTkSwitch(self.frame_tools, text="📁 Datei-Sandbox (8 Tools)")
        self.sw_files.pack(anchor="w", pady=4)

        self.sw_memory = ctk.CTkSwitch(self.frame_tools, text="🧠 Gedächtnis & Steno-Brain (6 Tools)")
        self.sw_memory.pack(anchor="w", pady=4)

        self.lbl_mcp_section = ctk.CTkLabel(self.frame_tools, text="── MCP Server ──", font=ctk.CTkFont(size=10, weight="bold"), text_color="gray")
        self.lbl_mcp_section.pack(anchor="w", pady=(8, 2))

        # --- LIVE-INSPEKTOR BUTTON ---
        self.btn_inspector = ctk.CTkButton(
            self.sidebar, 
            text="🔍 Live-Inspektor Öffnen", 
            fg_color="#10B981", 
            hover_color="#059669", 
            command=self._open_inspector
        )
        self.btn_inspector.pack(fill="x", padx=15, pady=(10, 2))

        # Steno-Brain Viewer Button
        self.btn_view_brain = ctk.CTkButton(self.sidebar, text="🔍 Steno-Brain Inspect", command=self._show_brain_inspector, fg_color="#3B82F6", hover_color="#2563EB")
        self.btn_view_brain.pack(fill="x", padx=15, pady=(5, 2))

        self.btn_save_cfg = ctk.CTkButton(self.sidebar, text="💾 Config Speichern", command=self._save_config_from_ui, fg_color="transparent", border_width=1)
        self.btn_save_cfg.pack(fill="x", padx=15, pady=(5, 5))

        # MAIN CHAT
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=10)
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(1, weight=0)
        self.main_frame.grid_rowconfigure(2, weight=0)
        self.main_frame.grid_rowconfigure(3, weight=0)
        self.main_frame.grid_columnconfigure(0, weight=1)

        self.txt_chat = ctk.CTkTextbox(self.main_frame, font=ctk.CTkFont(size=13), wrap="word")
        self.txt_chat.grid(row=0, column=0, sticky="nsew", padx=10, pady=(10, 5))
        self.txt_chat.configure(state="disabled")

        self.frame_attachment_preview = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frame_attachment_preview.grid(row=1, column=0, sticky="ew", padx=15, pady=(2, 2))

        self.lbl_attachment_info = ctk.CTkLabel(self.frame_attachment_preview, text="", font=ctk.CTkFont(size=12, weight="bold"), text_color="#3B82F6")
        self.lbl_attachment_info.pack(side="left")

        self.btn_remove_attachment = ctk.CTkButton(self.frame_attachment_preview, text="✕", width=25, height=20, fg_color="#EF4444", hover_color="#DC2626", command=self._clear_attachment)

        self.lbl_status = ctk.CTkLabel(self.main_frame, text="🟢 Bereit." + (" (Drag & Drop aktiv)" if HAS_DND else ""), anchor="w", font=ctk.CTkFont(size=12, weight="bold"), text_color="gray")
        self.lbl_status.grid(row=2, column=0, sticky="ew", padx=15, pady=2)

        self.frame_input = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frame_input.grid(row=3, column=0, sticky="ew", padx=10, pady=(5, 10))
        self.frame_input.grid_columnconfigure(1, weight=1)

        self.btn_attach = ctk.CTkButton(self.frame_input, text="📎", width=40, height=40, font=ctk.CTkFont(size=16), command=self._select_attachment, fg_color="#4B5563", hover_color="#374151")
        self.btn_attach.grid(row=0, column=0, padx=(0, 5), pady=5)

        placeholder = "Arbeitsauftrag eingeben oder Datei hierher ziehen..." if HAS_DND else "Gib deiner KI einen Arbeitsauftrag oder hänge eine Datei an..."
        self.entry_user = ctk.CTkEntry(self.frame_input, placeholder_text=placeholder, height=40)
        self.entry_user.grid(row=0, column=1, sticky="ew", padx=(0, 5), pady=5)
        self.entry_user.bind("<Return>", lambda e: self.send_message())

        self.btn_send = ctk.CTkButton(self.frame_input, text="Senden 🚀", width=100, height=40, command=self.send_message)
        self.btn_send.grid(row=0, column=2, padx=2, pady=5)

    def _select_workspace(self):
        folder_selected = filedialog.askdirectory(title="Projekt-Workspace Ordner wählen")
        if folder_selected:
            self.entry_workspace.delete(0, tk.END)
            self.entry_workspace.insert(0, folder_selected)
            tools.set_workspace_dir(folder_selected)

    def _open_inspector(self):
        """Öffnet das Inspektor-Fenster oder bringt es in den Fokus."""
        if self.inspector_win is None or not self.inspector_win.winfo_exists():
            self.inspector_win = InspectorWindow(self)
        else:
            self.inspector_win.focus()

    def _handle_step_callback(self, step_num, thought, action, observation):
        """Leitet die Ereignisse an das Live-Inspektor Fenster weiter."""
        if self.inspector_win and self.inspector_win.winfo_exists():
            self.inspector_win.log_step(step_num, thought, action, observation)

    def _import_mcp_dialog(self):
        file_path = filedialog.askopenfilename(
            title="MCP-Server Skript auswählen",
            filetypes=[
                ("MCP Skripte", "*.py *.js *.cjs *.mjs *.sh"),
                ("Alle Dateien", "*.*")
            ]
        )
        if file_path:
            server_name = mcp_manager.register_mcp_from_file(file_path)
            if server_name:
                messagebox.showinfo("MCP Import", f"MCP-Server '{server_name}' erfolgreich registriert!")
                self._load_dynamic_mcp_ui()
            else:
                messagebox.showerror("Fehler", "MCP-Server konnte nicht importiert werden.")

    def _load_dynamic_mcp_ui(self):
        for sw in self.mcp_switches.values():
            sw.destroy()
        self.mcp_switches.clear()

        mcp_configs = mcp_manager.load_mcp_config()
        for server_name, cfg in mcp_configs.items():
            is_enabled = cfg.get("enabled", True)
            sw = ctk.CTkSwitch(self.frame_tools, text=f"⚡ MCP: {server_name}")
            if is_enabled:
                sw.select()
            else:
                sw.deselect()
            
            sw.configure(command=lambda name=server_name, widget=sw: mcp_manager.toggle_server_status(name, bool(widget.get())))
            sw.pack(anchor="w", pady=4)
            self.mcp_switches[server_name] = sw

    def _select_attachment(self):
        file_path = filedialog.askopenfilename(
            title="Datei oder Bild anhängen",
            filetypes=[
                ("Alle unterstützten Dateien", "*.*"),
                ("Bilder", "*.png *.jpg *.jpeg *.webp *.gif"),
                ("Dokumente & Code", "*.txt *.md *.py *.csv *.json *.pdf *.html"),
            ]
        )
        if file_path:
            self._attach_file(Path(file_path))

    def _attach_file(self, path_obj: Path):
        self.attached_file_path = path_obj
        file_name = self.attached_file_path.name
        size_kb = round(self.attached_file_path.stat().st_size / 1024, 1)
        
        self.lbl_attachment_info.configure(text=f"📎 Angehängt: {file_name} ({size_kb} KB)")
        self.btn_remove_attachment.pack(side="left", padx=5)

    def _clear_attachment(self):
        self.attached_file_path = None
        self.lbl_attachment_info.configure(text="")
        self.btn_remove_attachment.pack_forget()

    def _show_brain_inspector(self):
        brain_window = ctk.CTkToplevel(self)
        brain_window.title("POCKET_AI — Steno-Brain Inspector")
        brain_window.geometry("600x450")
        brain_window.attributes("-topmost", True)

        lbl = ctk.CTkLabel(brain_window, text="Aktueller Langzeit-Zustand (.brain/index.md):", font=ctk.CTkFont(weight="bold"))
        lbl.pack(anchor="w", padx=15, pady=(15, 5))

        txt = ctk.CTkTextbox(brain_window, font=ctk.CTkFont(family="Consolas", size=12), wrap="none")
        txt.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        current_state = read_brain_state()
        txt.insert("1.0", current_state)
        txt.configure(state="disabled")

    def _test_connection(self):
        self.lbl_conn_status.configure(text="🟡 Teste...", text_color="yellow")
        url = self.entry_url.get().strip()
        key = self.entry_key.get().strip() or "lm-studio"
        model = self.combo_model.get().strip()

        def _worker():
            try:
                client = OpenAI(base_url=url, api_key=key)
                res = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": "hi"}],
                    max_tokens=5
                )
                self.after(0, lambda: self.lbl_conn_status.configure(text="🟢 Online", text_color="lime"))
            except Exception as e:
                err_msg = str(e)
                self.after(0, lambda: self.lbl_conn_status.configure(text="🔴 Fehler", text_color="red"))
                self.after(0, lambda msg=err_msg: messagebox.showerror("Verbindungsfehler", msg))

        threading.Thread(target=_worker, daemon=True).start()

    def send_message(self):
        user_text = self.entry_user.get().strip()
        if (not user_text and not self.attached_file_path) or self.is_running:
            return

        # Aktiven Workspace-Pfad setzen
        custom_workspace = self.entry_workspace.get().strip()
        if custom_workspace:
            tools.set_workspace_dir(custom_workspace)

        attachment_notice = ""
        if self.attached_file_path and self.attached_file_path.exists():
            try:
                tools.WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
                target_path = tools.WORKSPACE_DIR / self.attached_file_path.name
                shutil.copy2(self.attached_file_path, target_path)
                attachment_notice = f"\n[System-Hinweis: Der Benutzer hat die Datei '{self.attached_file_path.name}' im Workspace unter '{target_path}' angehängt. Bitte verarbeite/analysiere sie bei Bedarf.]"
            except Exception as e:
                attachment_notice = f"\n[Fehler beim Kopieren des Anhangs: {e}]"

        full_prompt = (user_text + attachment_notice).strip()
        display_text = user_text if user_text else f"📎 Datei gesendet: {self.attached_file_path.name}"
        if self.attached_file_path and user_text:
            display_text = f"📎 [{self.attached_file_path.name}]\n{user_text}"

        self.entry_user.delete(0, tk.END)
        self._clear_attachment()
        self._append_chat("User", display_text)

        self.is_running = True
        self.btn_send.configure(state="disabled")

        selected_auto = self.combo_autonomy.get()
        mode = "STRICT" if "STRICT" in selected_auto else ("UNATTENDED" if "UNATTENDED" in selected_auto else "WORKSPACE_SANDBOX")

        self.agent = PocketAgent(
            base_url=self.entry_url.get().strip(),
            api_key=self.entry_key.get().strip(),
            model=self.combo_model.get().strip(),
            autonomy_mode=mode,
        )

        active_tools = ["read_brain", "sync_brain"]

        if self.sw_web.get():
            active_tools.extend(["web_search", "scrape_webpage", "http_get_json", "download_file"])
        if self.sw_vision.get():
            active_tools.append("capture_webpage_screenshot")
        if self.sw_terminal.get():
            active_tools.extend(["exec_terminal", "get_system_info", "execute_python_code"])
        if self.sw_files.get() or attachment_notice:
            active_tools.extend(["create_folder_structure", "write_file", "read_file", "list_files", "delete_file", "copy_file", "file_exists", "get_file_info"])
        if self.sw_memory.get():
            active_tools.extend(["update_memory", "read_memory", "append_to_log", "list_logs"])

        active_tools = list(set(active_tools))

        threading.Thread(target=self._agent_worker, args=(full_prompt, active_tools), daemon=True).start()

    def _agent_worker(self, prompt: str, active_tools: list):
        try:
            response = self.agent.run_task(
                user_prompt=prompt,
                chat_history=self.chat_history,
                approval_callback=self._gui_approval_dialog,
                status_callback=self._update_status,
                active_tools_filter=active_tools,
                step_callback=self._handle_step_callback,
            )
            self.chat_history.append({"role": "user", "content": prompt})
            self.chat_history.append({"role": "assistant", "content": response})
            self._append_chat("POCKET_AI", response)
        except Exception as e:
            self._append_chat("System Error", f"Ein Fehler ist aufgetreten: {str(e)}")
        finally:
            self.is_running = False
            self.btn_send.configure(state="disabled" if False else "normal")
            self._update_status("🟢 Bereit." + (" (Drag & Drop aktiv)" if HAS_DND else ""))

    def _gui_approval_dialog(self, title: str, message: str) -> bool:
        result = [False]
        def _ask():
            result[0] = messagebox.askyesno(title, message, parent=self)
        self.after(0, _ask)
        import time
        time.sleep(0.5)
        return result[0]

    def _append_chat(self, sender: str, text: str):
        def _update():
            self.txt_chat.configure(state="normal")
            self.txt_chat.insert(tk.END, f"[{sender}]\n{text}\n\n" + "─" * 50 + "\n\n")
            self.txt_chat.see(tk.END)
            self.txt_chat.configure(state="disabled")
        self.after(0, _update)

    def _update_status(self, text: str):
        def _update():
            self.lbl_status.configure(text=text)
        self.after(0, _update)

    def _load_config(self) -> dict:
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            "server_url": "https://openrouter.ai/api/v1",
            "api_key": "",
            "model": "google/gemini-2.5-flash:free",
            "autonomy_mode": "WORKSPACE_SANDBOX (Ausgewogen)",
            "workspace_dir": str(WORKSPACE_DIR),
            "active_tools": {"web": True, "vision": True, "terminal": True, "files": True, "memory": True},
        }

    def _restore_config_to_ui(self):
        self.entry_url.delete(0, tk.END)
        self.entry_url.insert(0, self.config_data.get("server_url", ""))
        
        self.entry_key.delete(0, tk.END)
        self.entry_key.insert(0, self.config_data.get("api_key", ""))
        
        saved_workspace = self.config_data.get("workspace_dir", str(WORKSPACE_DIR))
        self.entry_workspace.delete(0, tk.END)
        self.entry_workspace.insert(0, saved_workspace)
        tools.set_workspace_dir(saved_workspace)

        saved_model = self.config_data.get("model", "google/gemini-2.5-flash:free")
        self.combo_model.set(saved_model)

        if self.config_data.get("active_tools", {}).get("web", True): self.sw_web.select()
        if self.config_data.get("active_tools", {}).get("vision", True): self.sw_vision.select()
        if self.config_data.get("active_tools", {}).get("terminal", True): self.sw_terminal.select()
        if self.config_data.get("active_tools", {}).get("files", True): self.sw_files.select()
        if self.config_data.get("active_tools", {}).get("memory", True): self.sw_memory.select()

    def _save_config_from_ui(self):
        cfg = {
            "server_url": self.entry_url.get().strip(),
            "api_key": self.entry_key.get().strip(),
            "model": self.combo_model.get().strip(),
            "autonomy_mode": self.combo_autonomy.get(),
            "workspace_dir": self.entry_workspace.get().strip(),
            "active_tools": {
                "web": bool(self.sw_web.get()),
                "vision": bool(self.sw_vision.get()),
                "terminal": bool(self.sw_terminal.get()),
                "files": bool(self.sw_files.get()),
                "memory": bool(self.sw_memory.get()),
            },
        }
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=4)
        messagebox.showinfo("Erfolg", "Einstellungen gespeichert!")


if __name__ == "__main__":
    app = PocketAIApp()
    app.mainloop()
