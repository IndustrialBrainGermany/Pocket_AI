import os
from pathlib import Path

BRAIN_DIR = Path("workspace/.brain")
INDEX_FILE = BRAIN_DIR / "index.md"

INITIAL_INDEX_TEMPLATE = """# BRAIN_INDEX
PROJ: POCKET_AI_TASK
STATE: INITIALIZED

[ENTITIES]
CORE_FILES: []

[STATE_BUFFER]
ACTIVE_TASK: None
COMPLETED_STEPS: []

[LOG_SHORT]
- System initialized.
"""

def init_brain():
    """Erstellt die .brain-Struktur, falls nicht vorhanden."""
    BRAIN_DIR.mkdir(parents=True, exist_ok=True)
    (BRAIN_DIR / "tasks").mkdir(exist_ok=True)
    
    if not INDEX_FILE.exists():
        INDEX_FILE.write_text(INITIAL_INDEX_TEMPLATE, encoding="utf-8")

def read_brain_state() -> str:
    """Liest den aktuellen Steno-Zustand für das Re-Hydrations-Prompt."""
    if INDEX_FILE.exists():
        return INDEX_FILE.read_text(encoding="utf-8")
    return "NO_BRAIN_STATE"

def update_brain_index(content: str):
    """Aktualisiert die globale Steno-Datei."""
    INDEX_FILE.write_text(content, encoding="utf-8")
