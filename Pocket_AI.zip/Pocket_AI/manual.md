# User Manual — Teil 1: Installation & Konfiguration

Release 31. August 2026.

Willkommen bei POCKET_AI!
Diese Anleitung führt dich Schritt für Schritt von Null bis zum ersten erfolgreichen Einsatz.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Schritt 1: Voraussetzungen & Installation

Du benötigst auf deinem Rechner Python (Version 3.10 oder neuer).

### Linux (Ubuntu / Debian / Arch / Fedora)

1. Terminal öffnen:
   Strg + Alt + T

2. Python & Systempakete installieren:
   sudo apt update && sudo apt install -y python3 python3-pip python3-venv

3. In den Projektordner wechseln:
   cd ~/Schreibtisch/Pocket_AI_V1   # Pfad ggf. anpassen

4. Python-Abhängigkeiten installieren (inkl. MCP-Standard):
   pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp

5. Optional (Web-Screenshots):
   playwright install chromium


### Windows

1. Python von python.org herunterladen und installieren
2. WICHTIG: "Add python.exe to PATH" aktivieren
3. CMD oder PowerShell öffnen

4. In den Ordner wechseln:
   cd C:\Pfad\zu\Pocket_AI_V1

5. Pakete installieren:
   pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
   playwright install chromium


### macOS

1. Terminal öffnen (Cmd + Leertaste → "Terminal")

2. Optional (mit Homebrew):
   brew install python

3. Pakete installieren:
   pip3 install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
   playwright install chromium

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Schritt 2: Anwendung starten

Im Ordner `Pocket_AI_V1`:

Linux / macOS:
   python3 app.py

Windows:
   python app.py

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Schritt 3: Erstkonfiguration & MCP-Integration

1. API Key eintragen:
   OpenRouter API-Key ins Feld "API Key" einfügen

2. Modell wählen:
   z. B. openrouter/free oder ein Modell mit ":free"

3. Verbindung testen:
   Button "Verbindung Testen" → Status sollte "Online" sein

4. MCP-Server einbinden (Visueller Import):
   - Klicke oben links in der Werkzeugleiste auf den grünen **`+ MCP`** Button.
   - Wähle die Start-Datei deines MCP-Servers aus (z. B. ein `.py`- oder `.js`-Skript).
   - Der Server wird automatisch eingerichtet und erscheint als neuer Schalter unter `── MCP Server ──`.
   - Schalte den Server nach Bedarf über den Regler EIN oder AUS.

5. Steno-Brain prüfen:
   Sidebar → "Steno-Brain Inspect"

6. Konfiguration speichern:
   Button "Config Speichern"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# POCKET_AI v1.0 — Technische Funktionsbeschreibung

POCKET_AI ist ein portabler, autonomer Desktop-Agent.
Er dient als intelligente Schnittstelle zwischen LLMs und deinem lokalen System.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1. Verbindungskonzept (Online vs. Lokal)

Der Agent nutzt das OpenAI-API-Format und kann flexibel betrieben werden:

### Online-Betrieb (OpenRouter / OpenAI / Groq)

- Base URL:
  https://openrouter.ai/api/v1

- API-Key:
  Persönlicher Provider-Key

- Modelle:
  Automatische Live-Abfrage verfügbarer Modelle
  (inkl. kostenloser Varianten wie "openrouter/free")


### Lokaler Betrieb (Offline)

- Tools:
  LM Studio, Ollama, LocalAI

- Base URLs:
  LM Studio → http://localhost:1234/v1
  Ollama   → http://localhost:11434/v1

- API-Key:
  Beliebiger Platzhalter (z. B. "lm-studio")

- Vorteil:
  Volle Privatsphäre, keine externen Requests

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 2. Steno-Gedächtnis (.brain)

Zur Umgehung von Token-Limits nutzt POCKET_AI ein komprimiertes Langzeitgedächtnis.

- Key-Value Stenografie:
  ~75 % Token-Einsparung gegenüber Fließtext

- Auto-Flush:
  Nach >10 Schritten wird Kontext geleert und aus `.brain/index.md` neu geladen

- Architektur:
  brain.py           → Zugriff auf Speicher
  .brain/index.md   → globaler Zustand
  .brain/tasks/     → Detailzustände

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 3. Toolsystem (Standard + Dynamische MCP-Erweiterung)

Steuerung erfolgt über die ReAct-Engine (`agent.py`).

### Standard-Werkzeuggruppen:

#### Gruppe 1: Web & Downloads
- web_search
- scrape_webpage
- http_get_json
- download_file
- capture_webpage_screenshot

#### Gruppe 2: Vision
- capture_webpage_screenshot

#### Gruppe 3: Terminal & Python
- exec_terminal
- get_system_info
- execute_python_code

#### Gruppe 4: Datei-Sandbox
- create_folder_structure
- write_file
- read_file
- list_files
- delete_file
- copy_file
- file_exists
- get_file_info

#### Gruppe 5: Gedächtnis
- read_brain
- sync_brain
- update_memory
- read_memory
- append_to_log
- list_logs

### Dynamische MCP-Erweiterung (Model Context Protocol)

POCKET_AI unterstützt die dynamische Erweiterung von Werkzeugen über das Model Context Protocol (MCP):

- **One-Click Importer:** Skripte (`.py`, `.js`, etc.) werden direkt im Datei-Dialog geladen.
- **Automatische Interpreter-Erkennung:** `.py`-Skripte nutzen die Anwendungs-Python-Environment (`sys.executable`), `.js`-Skripte nutzen `node`.
- **Lokale Registry:** Server-Informationen werden dauerhaft in `mcp_config.json` gespeichert.
- **Zombie-Process Cleanup:** Beim Schließen der Anwendung beendet der `MCPManager` sauber alle aktiven Subprozesse (`SIGTERM`/`SIGKILL`), um verwaiste Prozesse zu verhindern.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 4. Sicherheitskonzept

Drei Betriebsmodi:

- STRICT:
  Jede Aktion muss bestätigt werden

- WORKSPACE_SANDBOX (empfohlen):
  Autonom im workspace/, kritische Befehle benötigen Bestätigung

- UNATTENDED:
  Vollautomatisch ohne Rückfragen

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ENGLISH VERSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# User Manual — Part 1: Installation & Configuration

Welcome to POCKET_AI!
This guide walks you step by step from zero to your first successful run.

## Step 1: Requirements & Installation

You need Python (version 3.10 or newer).

Linux:
- Open terminal: Ctrl + Alt + T
- Install:
  sudo apt update && sudo apt install -y python3 python3-pip python3-venv
- Navigate:
  cd ~/Desktop/Pocket_AI_V1
- Install packages:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
- Optional:
  playwright install chromium

Windows:
- Install Python (enable "Add python.exe to PATH")
- Open CMD/PowerShell
- Navigate:
  cd C:\Path\to\Pocket_AI_V1
- Install:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

macOS:
- Open Terminal
- Install Python (optional):
  brew install python
- Install packages:
  pip3 install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

## Step 2: Start Application

Linux/macOS:
  python3 app.py

Windows:
  python app.py

## Step 3: First Configuration & MCP Import

- Enter API key (OpenRouter)
- Select model (e.g. openrouter/free)
- Test connection (status should be "Online")
- Add MCP Server: Click the green **`+ MCP`** button, select your server script (`.py` / `.js`), and toggle it ON in the sidebar.
- Check Steno-Brain (Sidebar)
- Save config

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SPANISH VERSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Manual de Usuario — Parte 1: Instalación y Configuración

Bienvenido a POCKET_AI.
Esta guía te lleva paso a paso desde cero hasta el primer uso exitoso.

## Paso 1: Requisitos e Instalación

Necesitas Python (versión 3.10 o superior).

Linux:
- Abrir terminal: Ctrl + Alt + T
- Instalar:
  sudo apt update && sudo apt install -y python3 python3-pip python3-venv
- Navegar:
  cd ~/Escritorio/Pocket_AI_V1
- Instalar paquetes:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
- Opcional:
  playwright install chromium

Windows:
- Instalar Python (activar "Add python.exe to PATH")
- Abrir CMD/PowerShell
- Navegar:
  cd C:\Ruta\Pocket_AI_V1
- Instalar:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

macOS:
- Abrir Terminal
- Instalar Python (opcional):
  brew install python
- Instalar paquetes:
  pip3 install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

## Paso 2: Iniciar Aplicación

Linux/macOS:
  python3 app.py

Windows:
  python app.py

## Paso 3: Configuración Inicial e Integración MCP

- Introducir API Key
- Elegir modelo (ej. openrouter/free)
- Probar conexión ("Online")
- Añadir servidor MCP: Haz clic en el botón verde **`+ MCP`**, selecciona tu script (`.py` / `.js`) y actívalo en la barra lateral.
- Revisar Steno-Brain
- Guardar configuración

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RUSSIAN VERSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Руководство пользователя — Часть 1: Установка и настройка

Добро пожаловать в POCKET_AI.
Это руководство проведет вас от нуля до первого запуска.

## Шаг 1: Требования и установка

Требуется Python (версия 3.10 или выше).

Linux:
- Открыть терминал: Ctrl + Alt + T
- Установить:
  sudo apt update && sudo apt install -y python3 python3-pip python3-venv
- Перейти:
  cd ~/Desktop/Pocket_AI_V1
- Установить пакеты:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
- Дополнительно:
  playwright install chromium

Windows:
- Установить Python (включить PATH)
- Открыть CMD/PowerShell
- Перейти:
  cd C:\Path\Pocket_AI_V1
- Установить:
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

macOS:
- Открыть терминал
- Установить Python:
  brew install python
- Установить пакеты:
  pip3 install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

## Шаг 2: Запуск

Linux/macOS:
  python3 app.py

Windows:
  python app.py

## Шаг 3: Первая настройка и импорт MCP

- Ввести API ключ
- Выбрать модель
- Проверить соединение
- Добавить сервер MCP: Нажмите зеленую кнопку **`+ MCP`**, выберите скрипт (`.py` / `.js`) и включите его в боковой панели.
- Проверить Steno-Brain
- Сохранить настройки

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHINESE VERSION (SIMPLIFIED)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 用户手册 — 第1部分：安装与配置

欢迎使用 POCKET_AI。
本指南将带你从零开始完成首次运行。

## 第一步：环境与安装

需要 Python 3.10 或以上版本。

Linux：
- 打开终端：Ctrl + Alt + T
- 安装：
  sudo apt update && sudo apt install -y python3 python3-pip python3-venv
- 进入目录：
  cd ~/Desktop/Pocket_AI_V1
- 安装依赖：
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
- 可选：
  playwright install chromium

Windows：
- 安装 Python（勾选 PATH）
- 打开 CMD / PowerShell
- 进入目录：
  cd C:\Path\Pocket_AI_V1
- 安装：
  pip install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

macOS：
- 打开终端
- 安装 Python：
  brew install python
- 安装依赖：
  pip3 install customtkinter openai duckduckgo_search requests beautifulsoup4 playwright mcp
  playwright install chromium

## 第二步：启动程序

Linux/macOS：
  python3 app.py

Windows：
  python app.py

## 第三步：首次配置与 MCP 导入

- 输入 API Key
- 选择模型（如 openrouter/free）
- 测试连接（显示 Online）
- 添加 MCP 服务端：点击左侧绿色的 **`+ MCP`** 按钮，选择脚本文件（如 `.py` 或 `.js`），并在侧边栏中开启。
- 检查 Steno-Brain
- 保存配置
