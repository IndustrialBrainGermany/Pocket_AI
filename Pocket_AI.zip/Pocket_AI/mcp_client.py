import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any

MCP_CONFIG_FILE = Path(__file__).parent / "mcp_config.json"

# Versuch, das offizielle MCP-SDK zu laden
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False


class MCPManager:
    """Verwaltet dynamische Verbindungen zu MCP-Servern via Stdio (JSON-RPC) und sichert Process Cleanup."""

    def __init__(self):
        self.running_processes: Dict[str, subprocess.Popen] = {}
        self.active_servers: Dict[str, Dict[str, Any]] = {}
        self.mcp_tools: List[Dict] = []

    def is_available(self) -> bool:
        """Prüft, ob die mcp-Bibliothek im Python-Environment vorhanden ist."""
        return MCP_AVAILABLE

    def load_mcp_config(self) -> dict:
        """Liest die registrierten MCP-Server aus der mcp_config.json."""
        if MCP_CONFIG_FILE.exists():
            try:
                return json.loads(MCP_CONFIG_FILE.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def save_mcp_config(self, config: dict):
        """Speichert die MCP-Konfiguration ab."""
        MCP_CONFIG_FILE.write_text(json.dumps(config, indent=4), encoding="utf-8")

    def register_mcp_from_file(self, script_path: str) -> Optional[str]:
        """Nimmt den Dateipfad eines MCP-Skripts entgegen, erkennt den Interpreter und speichert ihn in mcp_config.json."""
        path = Path(script_path).resolve()
        if not path.exists():
            return None

        # Server-Name aus Dateiname generieren (z. B. sqlite_mcp)
        server_name = path.stem.lower().replace("-", "_").replace(" ", "_")
        
        # Interpreter automatisch zuordnen
        if path.suffix == ".py":
            cmd = sys.executable  # Nutzt genau die Python-Runtime der App
        elif path.suffix in [".js", ".cjs", ".mjs"]:
            cmd = "node"
        else:
            cmd = str(path)

        config = self.load_mcp_config()
        config[server_name] = {
            "command": cmd,
            "args": [str(path)] if cmd != str(path) else [],
            "enabled": True,
            "script_path": str(path)
        }
        self.save_mcp_config(config)
        return server_name

    def toggle_server_status(self, server_name: str, enabled: bool):
        """Aktiviert oder deaktiviert einen MCP-Server in der Konfigurationsdatei."""
        config = self.load_mcp_config()
        if server_name in config:
            config[server_name]["enabled"] = enabled
            self.save_mcp_config(config)

    async def connect_to_server(self, server_name: str, command: str, args: List[str], env: Optional[Dict[str, str]] = None) -> bool:
        """Startet einen MCP-Server als Subprozess und liest seine verfügbaren Tools aus."""
        if not MCP_AVAILABLE:
            print("⚠️ MCP-Bibliothek nicht installiert ('pip install mcp').")
            return False

        try:
            server_params = StdioServerParameters(
                command=command,
                args=args,
                env=env
            )

            async with stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    tools_response = await session.list_tools()

                    self.active_servers[server_name] = {
                        "command": command,
                        "args": args,
                        "tools": []
                    }

                    for tool in tools_response.tools:
                        openai_formatted_tool = {
                            "type": "function",
                            "function": {
                                "name": f"mcp__{server_name}__{tool.name}",
                                "description": f"[MCP: {server_name}] {tool.description or ''}",
                                "parameters": tool.inputSchema if hasattr(tool, 'inputSchema') else {}
                            }
                        }
                        self.mcp_tools.append(openai_formatted_tool)
                        self.active_servers[server_name]["tools"].append(tool.name)

            print(f"✅ MCP-Server '{server_name}' verbunden ({len(tools_response.tools)} Tools).")
            return True

        except Exception as e:
            print(f"❌ Fehler beim Verbinden mit MCP '{server_name}': {e}")
            return False

    def stop_all_servers(self):
        """ZOMBIE-KILLER: Beendet alle aktiven MCP-Subprozesse hart beim Beenden von Pocket AI."""
        print("🧹 Beende MCP-Server & räume Subprozesse auf...")
        for name, proc in list(self.running_processes.items()):
            try:
                if proc.poll() is None:
                    proc.terminate()
                    proc.wait(timeout=2)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        self.running_processes.clear()
        print("✅ Alle Zombie-Prozesse eliminiert.")

    def get_openai_tools(self) -> List[Dict]:
        """Gibt alle aktiven MCP-Tools im OpenAI Schema zurück."""
        return self.mcp_tools


# Singleton-Instanz
mcp_manager = MCPManager()
