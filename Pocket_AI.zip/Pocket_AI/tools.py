import os
import json
import subprocess
import requests
from pathlib import Path
from bs4 import BeautifulSoup
import pypdf

# Pfad-Konfigurationen für den Agenten
BASE_DIR = Path(__file__).parent.resolve()
WORKSPACE_DIR = BASE_DIR / "workspace"
LOGS_DIR = BASE_DIR / "logs"
CONFIG_FILE = BASE_DIR / "config.json"

# Ordner automatisch erstellen, falls nicht vorhanden
WORKSPACE_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

# Maximum Zeichenanzahl für Datei- und Webseiten-Inhalte (Token-Schutz)
MAX_CONTENT_LENGTH = 15000


def set_workspace_dir(custom_path: str):
    """Ermöglicht der App, den aktiven Arbeitsordner dynamisch zu wechseln."""
    global WORKSPACE_DIR
    path = Path(custom_path).resolve()
    path.mkdir(parents=True, exist_ok=True)
    WORKSPACE_DIR = path


def get_file_path(file_path: str) -> Path:
    """Löst relative Pfade immer gegenüber dem aktuell eingestellten WORKSPACE_DIR auf."""
    path = Path(file_path)
    if not path.is_absolute():
        return WORKSPACE_DIR / file_path
    return path


def read_file(file_path: str) -> str:
    """Liest den Inhalt einer Text- oder PDF-Datei sicher ein.
    Falls eine PDF das Zeichen-Limit überschreitet, wird sie vollautomatisch
    in nummerierte Chunks zerlegt und im Workspace abgelegt.
    """
    path = get_file_path(file_path)

    if not path.exists():
        return f"Fehler: Datei '{file_path}' wurde nicht gefunden."

    try:
        # 1. PDF-Dateien verarbeiten mit Auto-Chunking
        if path.suffix.lower() == ".pdf":
            reader = pypdf.PdfReader(path)
            extracted_pages = []

            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    extracted_pages.append(f"--- Seite {i+1} ---\n{text}")

            full_text = "\n\n".join(extracted_pages)

            if not full_text.strip():
                return f"Hinweis: Die PDF '{path.name}' wurde gelesen, enthält aber keinen extrahierbaren Text."

            # Wenn die PDF klein genug ist -> direkt zurückgeben
            if len(full_text) <= MAX_CONTENT_LENGTH:
                return full_text

            # AUTOMATIK: Wenn die PDF zu groß ist, vollautomatisch in Chunks zerschneiden
            chunk_size = 12000  # Sichere Häppchengröße für das Kontextfenster
            chunks = [full_text[i:i + chunk_size] for i in range(0, len(full_text), chunk_size)]

            chunks_dir = WORKSPACE_DIR / "pdf_chunks"
            chunks_dir.mkdir(parents=True, exist_ok=True)

            created_files = []
            for idx, chunk in enumerate(chunks, 1):
                chunk_file = chunks_dir / f"{path.stem}_teil_{idx}.txt"
                chunk_file.write_text(chunk, encoding="utf-8")
                created_files.append(str(chunk_file.relative_to(WORKSPACE_DIR)))

            return (
                f"SYSTEM-AUTOMATIK: Die PDF '{path.name}' war sehr groß ({len(full_text)} Zeichen).\n"
                f"Sie wurde vollautomatisch in {len(chunks)} Chunks zerlegt und im Ordner 'pdf_chunks/' gespeichert:\n"
                f"{json.dumps(created_files, indent=2)}\n\n"
                f"AUFTRAG AN DIE KI: Lies diese Teildateien nacheinander mit 'read_file' ein, "
                f"fasse jeden Teil zusammen und erstelle daraus die finale Gesamtzusammenfassung."
            )

        # 2. Reguläre Textdateien verarbeiten (.txt, .md, .py, .json, etc.)
        else:
            content = path.read_text(encoding="utf-8", errors="replace")
            if len(content) > MAX_CONTENT_LENGTH:
                return (
                    f"{content[:MAX_CONTENT_LENGTH]}\n\n"
                    f"[HINWEIS: Datei war zu groß und wurde nach {MAX_CONTENT_LENGTH} Zeichen gekürzt.]"
                )
            return content

    except Exception as e:
        return f"Fehler beim Lesen der Datei '{file_path}': {str(e)}"


def write_file(file_path: str, content: str) -> str:
    """Schreibt oder überschreibt eine Datei sicher im Workspace."""
    try:
        path = get_file_path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return f"Erfolg: Datei '{file_path}' wurde erfolgreich gespeichert."
    except Exception as e:
        return f"Fehler beim Schreiben der Datei '{file_path}': {str(e)}"


def web_search(query: str) -> str:
    """Führt eine DuckDuckGo-Websuche durch und gibt gehärtete Ergebnisse zurück."""
    try:
        url = f"https://html.duckduckgo.com/html/?q={requests.utils.quote(query)}"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        results = []

        for a in soup.find_all("a", class_="result__snippet", limit=5):
            parent = a.find_parent("div", class_="result__body")
            title_elem = parent.find("a", class_="result__url") if parent else None
            
            title = title_elem.get_text(strip=True) if title_elem else "Kein Titel"
            link = title_elem["href"] if title_elem and "href" in title_elem.attrs else "#"
            snippet = a.get_text(strip=True)

            results.append(f"Titel: {title}\nURL: {link}\nAuszug: {snippet}\n")

        if not results:
            return "Keine relevanten Suchergebnisse gefunden."

        return "\n---\n".join(results)

    except Exception as e:
        return f"Fehler bei der Websuche: {str(e)}"


def scrape_webpage(url: str) -> str:
    """Liest den Reintext einer Webseite aus und bereinigt Skripte/CSS."""
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        for element in soup(["script", "style", "nav", "footer", "header"]):
            element.decompose()

        text = soup.get_text(separator="\n", strip=True)

        if len(text) > MAX_CONTENT_LENGTH:
            return (
                f"{text[:MAX_CONTENT_LENGTH]}\n\n"
                f"[HINWEIS: Webseite wurde nach {MAX_CONTENT_LENGTH} Zeichen gekürzt.]"
            )

        return text if text else "Fehler: Es konnte kein lesbarer Text auf der Seite gefunden werden."

    except Exception as e:
        return f"Fehler beim Scrapen der Seite '{url}': {str(e)}"


def exec_terminal(command: str) -> str:
    """Führt Konsolenbefehle aus und fängt Fehler ab."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        output = result.stdout.strip()
        error = result.stderr.strip()

        if result.returncode != 0:
            return f"Befehl fehlgeschlagen (Exit Code {result.returncode}):\n{error if error else output}"

        return output if output else "Befehl erfolgreich ausgeführt (keine Ausgabe)."

    except subprocess.TimeoutExpired:
        return "Fehler: Befehlslaufzeit hat das Limit von 30 Sekunden überschritten."
    except Exception as e:
        return f"Fehler beim Ausführen des Befehls: {str(e)}"


# Tool-Mapping für den Agenten
TOOL_MAP = {
    "read_file": read_file,
    "write_file": write_file,
    "web_search": web_search,
    "scrape_webpage": scrape_webpage,
    "exec_terminal": exec_terminal,
}

# OpenAI / OpenRouter kompatible Schema-Definitionen
TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Liest den Text aus einer Datei (PDF, TXT, MD, Code) im Workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Relativer oder absoluter Pfad zur Datei"}
                },
                "required": ["file_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Schreibt Inhalt in eine Datei im Workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Dateiname oder Pfad"},
                    "content": {"type": "string", "description": "Der zu schreibende Inhalt"}
                },
                "required": ["file_path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Sucht im Web nach Informationen via DuckDuckGo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Suchanfrage"}
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "scrape_webpage",
            "description": "Liest den Haupttext einer URL ein.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "Vollständige URL inkl. https://"}
                },
                "required": ["url"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "exec_terminal",
            "description": "Führt Konsolenbefehle im Terminal aus.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Der Terminal-Befehl"}
                },
                "required": ["command"]
            }
        }
    }
]
