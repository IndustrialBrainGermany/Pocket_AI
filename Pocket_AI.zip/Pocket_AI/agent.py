import json
from pathlib import Path
from typing import Callable, Dict, List, Optional
from openai import OpenAI

from brain import read_brain_state
from tools import BASE_DIR, LOGS_DIR, TOOL_DEFINITIONS, TOOL_MAP, WORKSPACE_DIR


class PocketAgent:

    def __init__(
        self,
        base_url: str = "https://openrouter.ai/api/v1",
        api_key: str = "",
        model: str = "meta-llama/llama-3.3-70b-instruct:free",
        autonomy_mode: str = "WORKSPACE_SANDBOX",
    ):
        self.base_url = base_url.strip()
        self.api_key = api_key.strip() if api_key.strip() else "lm-studio"
        self.model = model
        self.autonomy_mode = autonomy_mode

        self.max_steps = 30
        self.consecutive_error_limit = 3
        self.max_history_length = 10  # Schwelle für Auto-Flush / Kontext-Komprimierung

        self.client = OpenAI(base_url=self.base_url, api_key=self.api_key)

    def _get_system_prompt(self) -> str:
        memory_content = ""
        memory_file = WORKSPACE_DIR / "MEMORY.md"
        if memory_file.exists():
            try:
                memory_content = memory_file.read_text(
                    encoding="utf-8", errors="ignore"
                )
            except Exception:
                memory_content = ""

        # Steno-Gedächtnis laden (Re-Hydration)
        brain_state = read_brain_state()

        return f"""Du bist POCKET_AI, ein extrem fähiger, autonomer Desktop-Agent.
Du läufst lokal auf dem Computer des Nutzers.

[SYSTEM CONTEXT]
- Arbeitsverzeichnis (Workspace): {WORKSPACE_DIR}
- Aktueller Autonomie-Modus: {self.autonomy_mode}

[NATIVES STENO-GEDÄCHTNIS (.brain/index.md)]
{brain_state}

[STENO RULES FOR MEMORY MANAGEMENT]
Du besitzt ein ultrakompaktes Langzeitgedächtnis im Ordner `.brain/`.
Nutze das Tool `sync_brain`, um den System-Zustand, wichtige Fortschritte und Dateipfade im KI-Stenografie-Stil zu aktualisieren.
Regeln für Stenografie:
1. Keine Füllwörter, Pronomen oder Floskeln.
2. Nutze Schlüssel-Wert-Paare (z. B. `TASK: 001 | STATE: RUNNING | FILES: [a.py]`).
3. Halte den Inhalt präzise und extrem kurz (unter 200 Tokens).

[REGELN]
1. Nutze deine zur Verfügung stehenden Tools direkt, um Aufgaben auszuführen.
2. Wenn ein Befehl fehlschlägt, analysiere den Fehler und passe deine Vorgehensweise an.
3. Halte dich bei Dateioperationen vorzugsweise im Workspace-Ordner auf.

[KLASSISCHES GEDÄCHTNIS (MEMORY.md)]
{memory_content}
"""

    def _compress_context(self, messages: List[Dict], status_callback: Callable[[str], None]) -> List[Dict]:
        """Komprimiert den Kontext, indem alte Zwischenschritte entfernt werden und das Brain frisch gelesen wird."""
        status_callback("⚡ Komprimiere Kontext-Arbeitsspeicher (Auto-Flush)...")
        
        system_msg = messages[0]
        # Aktualisiere System-Prompt mit neustem Brain-State
        system_msg["content"] = self._get_system_prompt()
        
        # Behalte nur den System-Prompt und die letzten 3 Nachrichten (User/Assistant Interaktion)
        recent_messages = messages[-3:]
        
        return [system_msg] + recent_messages

    def run_task(
        self,
        user_prompt: str,
        chat_history: List[Dict],
        approval_callback: Callable[[str, str], bool],
        status_callback: Callable[[str], None],
        active_tools_filter: Optional[List[str]] = None,
        step_callback: Optional[Callable[[int, str, str, str], None]] = None,
    ) -> str:
        # Aktive Werkzeuge filtern
        available_tools = TOOL_DEFINITIONS
        if active_tools_filter is not None:
            available_tools = [
                t
                for t in TOOL_DEFINITIONS
                if t["function"]["name"] in active_tools_filter
            ]

        messages = [{"role": "system", "content": self._get_system_prompt()}]
        messages.extend(chat_history)
        messages.append({"role": "user", "content": user_prompt})

        step_count = 0
        consecutive_errors = 0

        while step_count < self.max_steps:
            step_count += 1

            # AUTO-FLUSH: Wenn die Nachrichtenhistorie zu lang wird, Kontext bereinigen
            if len(messages) > self.max_history_length:
                messages = self._compress_context(messages, status_callback)

            status_callback(
                f"🧠 KI denkt nach... (Schritt {step_count}/{self.max_steps})"
            )

            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    tools=(
                        available_tools if len(available_tools) > 0 else None
                    ),
                    tool_choice=(
                        "auto" if len(available_tools) > 0 else None
                    ),
                )
            except Exception as e:
                err_str = f"❌ Fehler bei der API-Anfrage: {str(e)}"
                if step_callback:
                    step_callback(step_count, "API-Anfrage fehlgeschlagen", "KEINE AKTION", err_str)
                return err_str

            response_message = response.choices[0].message
            messages.append(response_message)

            thought = response_message.content or "Verarbeite Aufgabe..."

            if not response_message.tool_calls:
                status_callback("✅ Aufgabe abgeschlossen.")
                if step_callback:
                    step_callback(step_count, thought, "KEIN TOOL (Finale Antwort)", thought)
                return thought

            for tool_call in response_message.tool_calls:
                function_name = tool_call.function.name
                arguments_raw = tool_call.function.arguments

                try:
                    arguments = json.loads(arguments_raw)
                except json.JSONDecodeError:
                    arguments = {}

                status_callback(f"🛠️ Tool-Anforderung: {function_name}")

                is_approved = self._check_permissions(
                    function_name, arguments, approval_callback
                )

                if not is_approved:
                    result = {
                        "status": "error",
                        "error": "Aktion vom Benutzer im UI abgelehnt.",
                    }
                    status_callback(
                        f"⛔ Aktion '{function_name}' abgelehnt."
                    )
                else:
                    if function_name in TOOL_MAP:
                        status_callback(f"⚡ Führe aus: {function_name}...")
                        result = TOOL_MAP[function_name](**arguments)
                    else:
                        result = {
                            "status": "error",
                            "error": f"Tool '{function_name}' nicht gefunden.",
                        }

                # LIVE-INSPEKTOR CALLBACK
                if step_callback:
                    action_str = f"{function_name}({json.dumps(arguments, ensure_ascii=False)})"
                    obs_str = json.dumps(result, ensure_ascii=False, indent=2) if isinstance(result, (dict, list)) else str(result)
                    step_callback(step_count, thought, action_str, obs_str)

                if isinstance(result, dict) and result.get("status") == "error":
                    consecutive_errors += 1
                else:
                    consecutive_errors = 0

                messages.append(
                    {
                        "tool_call_id": tool_call.id,
                        "role": "tool",
                        "name": function_name,
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )

            if consecutive_errors >= self.consecutive_error_limit:
                status_callback("⚠️ Autonomie gestoppt: Zu viele Fehler.")
                return "⚠️ **Schleife abgebrochen**: Der Agent stieß 3-mal hintereinander auf Fehler."

        status_callback("⚠️ Max. Schritte erreicht.")
        return "⚠️ Das maximale Schritt-Limit wurde erreicht."

    def _check_permissions(
        self,
        function_name: str,
        arguments: dict,
        approval_callback: Callable[[str, str], bool],
    ) -> bool:
        if self.autonomy_mode == "UNATTENDED":
            return True

        if self.autonomy_mode == "STRICT":
            return approval_callback(
                f"Sicherheitsfreigabe ({function_name})",
                f"Die KI möchte das Werkzeug '{function_name}' ausführen:\n\n{json.dumps(arguments, indent=2)}",
            )

        if self.autonomy_mode == "WORKSPACE_SANDBOX":
            if function_name == "exec_terminal":
                cmd = arguments.get("command", "")
                if any(
                    danger in cmd
                    for danger in [
                        "rm -rf /",
                        "sudo",
                        "mkfs",
                        "dd",
                        "> /dev/",
                    ]
                ):
                    return approval_callback(
                        "⚠️ Gefährlicher Terminal-Befehl!",
                        f"Kritischer Systembefehl:\n\n'{cmd}'\n\nErlauben?",
                    )
                return True
            return True

        return True
